﻿<h1>Aplicativo Calculadora</h1>
<p>Autor: Juliano Denner da Rocha<br>E-mail: jdenner@outlook.com</p>
<p>Aplicação desenvolvida como material de apoio ao aprendizado de programação para Android. É fornecida gratuitamente "no estado em que se encontra", isentando o autor de qualquer garantia ou danos que possam resultar do uso da mesma.</p>
<p>Ferramentas utilizadas:
  <ul>
    <li>Android Studio 1.2.1</li>
    <li>Android SDK Tools 24.2</li>	
    <li>JDK 1.8.0 u65</li>
    <li>Windows 7 Professional sp1</li>
  </ul>
</p>
<p>Pré-visualização:</p>
<img src="http://jdenner.com/github/android-calculadora.png" alt="Pré-visualização calculadora">
